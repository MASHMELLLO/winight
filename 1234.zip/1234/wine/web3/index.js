const Web3 = require('web3')
const config = require('config')

/** Configure web3 */
const web3 = new Web3(
  new Web3.providers.HttpProvider(config.blockchain.baseUrl)
)
web3.eth.defaultAccount = web3.eth.accounts[0]
web3.personal.unlockAccount(web3.eth.defaultAccount, "", 1000)
const contract = web3.eth.contract([
   {
      "constant": false,
      "inputs": [
         {
            "name": "a",
            "type": "string"
         }
      ],
      "name": "geta",
      "outputs": [
         {
            "name": "",
            "type": "int256"
         }
      ],
      "payable": false,
      "stateMutability": "nonpayable",
      "type": "function"
   },
   {
      "constant": false,
      "inputs": [
         {
            "name": "a",
            "type": "string"
         },
         {
            "name": "b",
            "type": "int256"
         }
      ],
      "name": "seta",
      "outputs": [],
      "payable": false,
      "stateMutability": "nonpayable",
      "type": "function"
   }
]).at('0xa223d4fb7aa6420c029a395fdea6fcda63c4da37')

module.exports = contract
