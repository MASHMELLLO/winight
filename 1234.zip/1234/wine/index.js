const http = require('http')
const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const cors = require('cors')
const morgan = require('morgan')
const config = require('config')
const router = require('./router.js')

/** Configure express */
app.use(cors())
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())
app.use('/api/v1', morgan('dev'))

/** Setup basic routes */
app.use('/api/v1', router)

/** Create API server */
const httpServer = http.createServer(app)
httpServer.listen(config.server.port, config.server.host, () => {
  console.log(`API Server listening on (host, port): (${httpServer.address().address}, ${httpServer.address().port})`)
})
