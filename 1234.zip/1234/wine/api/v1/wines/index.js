const config = require('config')
const rq = require('request-promise')

exports.getList = async (req, res) => {
  const page = req.query.page || 1

  try {
    const resp = JSON.parse(await rq.get(`${config.wine.apiEndpoint}?offset=${pageToOffset(page)}`, {
      headers: {
        'Authorization': `Token ${config.wine.apiKey}`
      },
      rejectUnauthorized: false
    }))
    const data = resp
    .results
    .map(d => Object.assign({}, {
      wind: d.wine,
      wine_id: d.wind_id,
      color: d.color,
      country: d.country,
      regions: d.regions,
      score: 0 // TODO
    }))
    return res.send({
      total_pages: Math.ceil(resp.count / 100),
      current_page: page,
      data
    })
  }
  catch (e) {
    return res.sendStatus(e)
  }
}

function pageToOffset(page) {
  return (page - 1) * 100
}
