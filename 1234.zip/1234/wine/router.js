const router = require('express').Router()
const wines = require('./api/v1/wines')

router.get('/wines', wines.getList)

module.exports = router
